﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P30481921001
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] vendas = new double[1, 4];
            double[] totalPorSemana = new double[4];
            double totalMes = 0.0;
            double totalGeral = 0.0;
            int i, j;
            string semana = "Total do mês: ";
            string mes = "\n>>Total Mês ";
            string geral = "\n>>Total Geral: R$";

            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    if (!double.TryParse(Interaction.InputBox("Digite o número de vendas: (Mês " + (i + 1) + " / Semana " + (j + 1) + ")"), out vendas[i, j]))
                    {
                        MessageBox.Show("Valor inválido.");
                        j--;
                    }
                    else
                    {
                        totalPorSemana[i] = vendas[i, j];
                        totalMes += vendas[i, j];
                        lstbxResultado.Items.Add(semana + (i+1) + " Semana: " + (j + 1) + " R$" + (totalPorSemana[i].ToString("C")));
                    }
                }
                lstbxResultado.Items.Add(mes + (i + 1) + ": R$" + (totalMes.ToString("C")));
            }
            totalGeral = totalMes;
            lstbxResultado.Items.Add(geral + (totalGeral.ToString("C")));

        }


    }
}
