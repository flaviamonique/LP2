﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P.Atividade_6
{
    public partial class FormEx1 : Form
    {
        public FormEx1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int x = 0, n = 0;
            while (x < rchText.Text.Length)
            {
                if (Char.IsWhiteSpace(rchText.Text[x]))
                   n += 1;
                 x += 1;
            }
            MessageBox.Show("Quantidade de espaços em branco: " + (n));
    }

        private void btnR_Click(object sender, EventArgs e)
        {
            int x = 0;
            foreach (char r in rchText.Text)
            {
                if (r == 'r')
                    x += 1;
            }
            MessageBox.Show("Quantidade de letra R: " + x);
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            int x = 0;
            int num = 0;
            string letra = "r";
            for (x = 0; x <= rchText.Text.Length-1; x++)
            {
                if ((rchText.Text.Substring(x, 1) != "") && (rchText.Text.Substring(x, 1) == letra))
                    num += 1;
                letra = rchText.Text.Substring(x, 1);
            }
            MessageBox.Show("Quantidade de pares: " + num);
        }
    }
}
