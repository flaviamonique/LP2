﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P.Atividade_6
{
    public partial class FormEx3 : Form
    {
        public FormEx3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string texto = txtText.Text, textosem = "";
            int cont, resultado = 1;

            if (txtText.Text.Length < 50)
            {

                foreach (char caractere in texto.ToCharArray())
                {
                    //Condição para verificar se algum sinal ortográfico ou espaço
                    if (caractere != ' ' && caractere != ',' && caractere != '?' && caractere != '!' && caractere != '.' && caractere != '-')
                    {
                        if (caractere.ToString().ToUpper() == "Ã" || caractere.ToString().ToUpper() == "Á" || caractere.ToString().ToUpper() == "À")
                        {
                            textosem += "A";
                        }
                        else if (caractere.ToString().ToUpper() == "Ê" || caractere.ToString().ToUpper() == "É" || caractere.ToString().ToUpper() == "È")
                        {
                            textosem += "E";
                        }
                        else if (caractere.ToString().ToUpper() == "Í" || caractere.ToString().ToUpper() == "Ì")
                        {
                            textosem += "I";
                        }
                        else if (caractere.ToString().ToUpper() == "Õ" || caractere.ToString().ToUpper() == "Ô" || caractere.ToString().ToUpper() == "Ó" || caractere.ToString().ToUpper() == "Ò")
                        {
                            textosem += "O";
                        }
                        else if (caractere.ToString().ToUpper() == "Ú" || caractere.ToString().ToUpper() == "Ù")
                        {
                            textosem += "U";
                        }
                        else
                        {
                            textosem += caractere.ToString().ToUpper();
                        }
                        
                    }
                }
                cont = textosem.Length - 1;

                for (int i = 0; i < textosem.Length - 1; i++)
                {
                    char crescente = textosem[i];
                    char decrescente = textosem[cont];

                    //condição para comparar a mesma posição considerando o texto normal e o texto reverso
                    if (crescente != decrescente)
                    {
                        resultado = 0; 
                    }
                    else
                    {
                        cont--;
                    }
                }

                if (resultado == 1)
                {
                    MessageBox.Show("O texto é palíndromo!");
                }
                else
                {
                    MessageBox.Show("O texto NÃO é palíndromo!");
                }
            }
            else
            {
                MessageBox.Show("O texto pode ter no máximo 50 caracteres");
            }           

        }
    }
}
