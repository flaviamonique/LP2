﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P.Atividade_6
{
    public partial class FormEx4 : Form
    {
        public FormEx4()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            string nomeFuncionario, NomeCargo;
            int NumInscricao, producao, gratificacao, b = 0, c = 0, d = 0;
            double salario, salarioBruto, a;

            nomeFuncionario = txtNome.Text;
            NomeCargo = txtCargo.Text;
            NumInscricao = Convert.ToInt32(txtNum.Text);
            producao = Convert.ToInt32(txtProducao.Text);
            gratificacao = Convert.ToInt32(txtGratificacao.Text);
            salario = Convert.ToDouble(txtSal.Text);

            if (salario > 0)
            {
                if (salario <= 7000)
                {
                    a = salario;

                    if (producao >= 100)
                    {
                        b = 1;
                        if (producao >= 120)
                        {
                            c = 1;
                            if (producao >= 150)
                            {
                                d = 1;
                            }
                        }
                    }

                    salarioBruto = a + a * (0.05*b + 0.1*c + 0.1*d) + gratificacao;

                    if (salarioBruto > 7000 && producao >= 150 && gratificacao >= 1)
                    {
                        MessageBox.Show("O salário bruto calculado é de R$ " + String.Format("{0:0.#0}", salarioBruto) + " e por sua produção ser MAIOR que 150 e possuir gratificação, esse será seu salário bruto.");
                    }
                    else if (salarioBruto > 7000 && producao < 150)
                    {
                        MessageBox.Show("O salário bruto calculado é de R$ " + String.Format("{0:0.#0}", salarioBruto) + ", mas sua produção foi MENOR que 150, então seu salário bruto passa a ser R$ 7.000,00.");
                    }
                    else if (salarioBruto > 7000 && gratificacao < 1)
                    {
                        MessageBox.Show("O salário bruto calculado é de R$ " + String.Format("{0:0.#0}", salarioBruto) + ", mas você não possui gratificação, então seu salário bruto passa a ser R$ 7.000,00.");
                    }
                    else
                    {
                        MessageBox.Show("O salário bruto calculado é de R$ " + String.Format("{0:0.#0}", salarioBruto));
                    }
                }
                else
                {
                    MessageBox.Show("O salário preenchido não pode ser maior que R$ 7.000,00.");
                }

            }
            else
            {
                MessageBox.Show("O salário preenchido precisa ser maior que R$ 0,00.");
            }
        }
    }
}
