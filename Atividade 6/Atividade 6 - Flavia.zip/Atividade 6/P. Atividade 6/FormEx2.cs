﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P.Atividade_6
{
    public partial class FormEx2 : Form
    {
        public FormEx2()
        {
            InitializeComponent();
        }

        private void btnGerar_Click(object sender, EventArgs e)
        {
            int n = 0, x;
            float h = 0;

            n = Convert.ToInt32(txtN.Text);
            for (x = 1;x <= n; x++)
            {
                h = h + (float)1 / x;
            }
            MessageBox.Show("O resultado de H é: " + h);

        }
    }
}
