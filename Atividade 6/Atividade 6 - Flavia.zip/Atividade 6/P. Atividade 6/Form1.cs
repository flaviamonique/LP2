﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P.Atividade_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            Form formExerc1 = Application.OpenForms["FormEx1"];
            Form formExerc2 = Application.OpenForms["FormEx2"];
            Form formExerc3 = Application.OpenForms["FormEx3"];
            Form formExerc4 = Application.OpenForms["FormEx4"];

            if (formExerc1 != null)
            {
                formExerc1.Close();
            }
            if (formExerc2 != null)
            {
                formExerc2.Close();
            }
            if (formExerc3 != null)
            {
                formExerc3.Close();
            }
            if (formExerc4 != null)
            {
                formExerc4.Close();
            }

            FormEx1 frm1 = new FormEx1();
            frm1.WindowState = FormWindowState.Maximized;
            frm1.Show();
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {

            Form formExerc1 = Application.OpenForms["FormEx1"];
            Form formExerc2 = Application.OpenForms["FormEx2"];
            Form formExerc3 = Application.OpenForms["FormEx3"];
            Form formExerc4 = Application.OpenForms["FormEx4"];

            if (formExerc1 != null)
            {
                formExerc1.Close();
            }
            if (formExerc2 != null)
            {
                formExerc2.Close();
            }
            if (formExerc3 != null)
            {
                formExerc3.Close();
            }
            if (formExerc4 != null)
            {
                formExerc4.Close();
            }

            FormEx2 frm2 = new FormEx2();
            frm2.WindowState = FormWindowState.Maximized;
            frm2.Show();
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            Form formExerc1 = Application.OpenForms["FormEx1"];
            Form formExerc2 = Application.OpenForms["FormEx2"];
            Form formExerc3 = Application.OpenForms["FormEx3"];
            Form formExerc4 = Application.OpenForms["FormEx4"];

            if (formExerc1 != null)
            {
                formExerc1.Close();
            }
            if (formExerc2 != null)
            {
                formExerc2.Close();
            }
            if (formExerc3 != null)
            {
                formExerc3.Close();
            }
            if (formExerc4 != null)
            {
                formExerc4.Close();
            }

            FormEx3 frm3 = new FormEx3();
            frm3.WindowState = FormWindowState.Maximized;
            frm3.Show();
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            Form formExerc1 = Application.OpenForms["FormEx1"];
            Form formExerc2 = Application.OpenForms["FormEx2"];
            Form formExerc3 = Application.OpenForms["FormEx3"];
            Form formExerc4 = Application.OpenForms["FormEx4"];

            if (formExerc1 != null)
            {
                formExerc1.Close();
            }
            if (formExerc2 != null)
            {
                formExerc2.Close();
            }
            if (formExerc3 != null)
            {
                formExerc3.Close();
            }
            if (formExerc4 != null)
            {
                formExerc4.Close();
            }

            FormEx4 frm4 = new FormEx4();
            frm4.WindowState = FormWindowState.Maximized;
            frm4.Show();
        }
    }
}
