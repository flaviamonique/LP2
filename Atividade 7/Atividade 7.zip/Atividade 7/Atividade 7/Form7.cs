﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade_7
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string sembrancos = "";

            string nomes = (Interaction.InputBox("Digite o nome ", "Entrada de dados"));
            
            foreach (char c in nomes.ToCharArray())
            {
                if (c != ' ')
                    sembrancos += c;
            }

            string resposta = "O nome: " + nomes + " tem " + sembrancos.Length + " caracteres.";

            lboxResultado.Items.Add(resposta);


        }
}
}