﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Atividade_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn20num_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            int x = 0;
            string auxiliar = "";
            string valor = "";
            
            for (x=0;x<20;x++)
            {
                valor = Interaction.InputBox("Digite o dado" +(x+1), "Entrada de dados");

                if (int.TryParse(valor, out vetor[x]))
                    auxiliar = vetor[x].ToString() + "\n" + auxiliar;
                else
                {
                    MessageBox.Show("Número Inválido");
                    x--;
                }
            }
            MessageBox.Show(auxiliar);
        }

        private void btnReverse_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            int x = 0;
            string auxiliar = "";
            string valor = "";
            
            for (x=0;x<20;x++)
            {
                valor = Interaction.InputBox("Digite o dado da posição " + (x + 1),
                    "Digitação dos dados");
                if (!int.TryParse(valor, out vetor[x]))
                {
                    MessageBox.Show("Número inválido");
                    x--;
                }

             }
            Array.Reverse(vetor);

            for (x = 0; x < 20; x++)
                auxiliar += vetor[x] + "\n";

            MessageBox.Show(auxiliar);
        }

        private void btnMercadorias_Click(object sender, EventArgs e)
        {
            double[] quantidade = new double[10];
            double[] valores = new double[10];
            int x = 0;
            double resultado = 0;
            string auxiliar = "";
            string valor = "";

            for (x = 0; x<10;x++)
            {
                valor = Interaction.InputBox("Digite a quantidade " + (x + 1),
                    "Digitação dos dados");
                if (!double.TryParse(valor, out quantidade[x]))
                {
                    MessageBox.Show("Número inválido");
                    x--;
                    continue;
                }
            valor = Interaction.InputBox("Digite o valor da mercadoria " + (x + 1));
            while (!double.TryParse(valor, out valores[x]))
            {
                MessageBox.Show("Número inválido");
                valor = Interaction.InputBox("Digite o valor da mercadoria " + (x + 1));
            }

         }
            for (x = 0; x < 10; x++)
                resultado += quantidade[x] * valores[x];
            MessageBox.Show("Faturamento mensal: " + resultado.ToString());
        }

        private void btnVariavel_Click(object sender, EventArgs e)
        {
            String[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
            "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;

            for (I = 0; I < N - 1; I++)
                Total += Alunos[I].Length;
            MessageBox.Show("Resultado é " + Total);

        }

        private void btnArrayList_Click(object sender, EventArgs e)
        {
            ArrayList ListAlunos = new ArrayList();

            ListAlunos.Add("Ana");
            ListAlunos.Add("André");
            ListAlunos.Add("Débora");
            ListAlunos.Add("Fátima");
            ListAlunos.Add("João");
            ListAlunos.Add("Janete");
            ListAlunos.Add("Otávio");
            ListAlunos.Add("Marcelo");
            ListAlunos.Add("Pedro");
            ListAlunos.Add("Thais");

            ListAlunos.Remove("Otávio");
            string alunos = "";
            foreach (string nome in ListAlunos)
                alunos += nome + ", ";
            MessageBox.Show(alunos);

        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            double[,] Notas = new double[20, 3];
            int contador = 0;
            int x = 0;
            string num = "";
            double media = 0;
            
            for (x = 0; x < 20; x++)
            {
                for (contador = 0; contador < 3; contador++)
                {
                    num = Interaction.InputBox("Digite a nota do aluno " +(x+1) + ", disciplina " + (contador + 1),
                    "Digitação das notas dados");

                    if(double.TryParse(num, out Notas[x,contador]))
                    {
                        if (Notas[x, contador] >= 0 && Notas[x, contador] <= 10)
                            media += Notas[x, contador];
                        else
                        {
                            MessageBox.Show("Média deve estar em 0 e 10");
                            contador--;
                        }
                    }
                    else
                        {
                            MessageBox.Show("Número Inválido");
                            contador--;
                        }
                }
                MessageBox.Show("A média do aluno " + (x + 1) + " é: " + (media / 3));
            }
    }

        private void btnEx7_Click(object sender, EventArgs e)
        {
            Form7 Form7 = new Form7();
            Form7.WindowState = FormWindowState.Maximized;
            Form7.Show();
        }
    }
}
