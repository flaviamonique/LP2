﻿namespace Atividade_7
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn20num = new System.Windows.Forms.Button();
            this.btnReverse = new System.Windows.Forms.Button();
            this.btnArrayList = new System.Windows.Forms.Button();
            this.btnMercadorias = new System.Windows.Forms.Button();
            this.btnVariavel = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnEx7 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn20num
            // 
            this.btn20num.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn20num.Location = new System.Drawing.Point(107, 78);
            this.btn20num.Name = "btn20num";
            this.btn20num.Size = new System.Drawing.Size(149, 70);
            this.btn20num.TabIndex = 0;
            this.btn20num.Text = "Ler 20 Números (Exercício 1)";
            this.btn20num.UseVisualStyleBackColor = true;
            this.btn20num.Click += new System.EventHandler(this.btn20num_Click);
            // 
            // btnReverse
            // 
            this.btnReverse.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReverse.Location = new System.Drawing.Point(323, 78);
            this.btnReverse.Name = "btnReverse";
            this.btnReverse.Size = new System.Drawing.Size(149, 70);
            this.btnReverse.TabIndex = 1;
            this.btnReverse.Text = "Uso do Reverse (Exercício 2)";
            this.btnReverse.UseVisualStyleBackColor = true;
            this.btnReverse.Click += new System.EventHandler(this.btnReverse_Click);
            // 
            // btnArrayList
            // 
            this.btnArrayList.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArrayList.Location = new System.Drawing.Point(326, 213);
            this.btnArrayList.Name = "btnArrayList";
            this.btnArrayList.Size = new System.Drawing.Size(149, 70);
            this.btnArrayList.TabIndex = 2;
            this.btnArrayList.Text = "Uso ArrayList (Exercício 5)";
            this.btnArrayList.UseVisualStyleBackColor = true;
            this.btnArrayList.Click += new System.EventHandler(this.btnArrayList_Click);
            // 
            // btnMercadorias
            // 
            this.btnMercadorias.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMercadorias.Location = new System.Drawing.Point(537, 78);
            this.btnMercadorias.Name = "btnMercadorias";
            this.btnMercadorias.Size = new System.Drawing.Size(149, 70);
            this.btnMercadorias.TabIndex = 3;
            this.btnMercadorias.Text = "Mercadorias (Exercício 3)";
            this.btnMercadorias.UseVisualStyleBackColor = true;
            this.btnMercadorias.Click += new System.EventHandler(this.btnMercadorias_Click);
            // 
            // btnVariavel
            // 
            this.btnVariavel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVariavel.Location = new System.Drawing.Point(107, 213);
            this.btnVariavel.Name = "btnVariavel";
            this.btnVariavel.Size = new System.Drawing.Size(149, 70);
            this.btnVariavel.TabIndex = 4;
            this.btnVariavel.Text = "Variável total (Exercício 4)";
            this.btnVariavel.UseVisualStyleBackColor = true;
            this.btnVariavel.Click += new System.EventHandler(this.btnVariavel_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedia.Location = new System.Drawing.Point(537, 213);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(149, 70);
            this.btnMedia.TabIndex = 5;
            this.btnMedia.Text = "Média (Exercício 6)";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnEx7
            // 
            this.btnEx7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEx7.Location = new System.Drawing.Point(326, 326);
            this.btnEx7.Name = "btnEx7";
            this.btnEx7.Size = new System.Drawing.Size(149, 70);
            this.btnEx7.TabIndex = 6;
            this.btnEx7.Text = "Exercício 7";
            this.btnEx7.UseVisualStyleBackColor = true;
            this.btnEx7.Click += new System.EventHandler(this.btnEx7_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnEx7);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnVariavel);
            this.Controls.Add(this.btnMercadorias);
            this.Controls.Add(this.btnArrayList);
            this.Controls.Add(this.btnReverse);
            this.Controls.Add(this.btn20num);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn20num;
        private System.Windows.Forms.Button btnReverse;
        private System.Windows.Forms.Button btnArrayList;
        private System.Windows.Forms.Button btnMercadorias;
        private System.Windows.Forms.Button btnVariavel;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnEx7;
    }
}

