﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ex2.Aula5
{
    public partial class frmSalario : Form
    {
        public frmSalario()
        {
            InitializeComponent();
        }

        private void btnVerificaDesconto_Click(object sender, EventArgs e)
        {
            double salBruto = Convert.ToDouble(mTxtSalarioBruto.Text);
            int numFilhos = Convert.ToInt32(mTxtNumeroFilhos.Text);
            double descontoINSS, salLiquido, salFamilia, aliquotaIRPF;
            descontoINSS = salLiquido = salFamilia = aliquotaIRPF = 0;

            if (salBruto < 800.47)
            {
                mTxtAliINSS.Text = "7,65%";
                mTxtAliquotaIRPF.Text = "0";
                descontoINSS = 0.0765 * salBruto;
                salLiquido = salBruto - descontoINSS;
                if (salBruto <= 654.61)
                {
                    if (salBruto < 435.52)
                    {
                        salFamilia = numFilhos * 22.33;
                        mTxtSalarioFamilia.Text = Convert.ToString(salFamilia);
                        salLiquido += salFamilia;
                    }
                    else
                    {
                        salFamilia = numFilhos * 15.74;
                        mTxtSalarioFamilia.Text = Convert.ToString(salFamilia);
                        salLiquido += salFamilia;
                    }
                }
            }
            else
            {
                mTxtSalarioFamilia.Text = "0";
                if (salBruto >= 800.48 && salBruto <= 1050)
                {
                    mTxtAliINSS.Text = "8,65%";
                    mTxtAliquotaIRPF.Text = "0";
                    descontoINSS = 0.0865 * salBruto;
                    salLiquido = salBruto - descontoINSS;
                }
                else if (salBruto >= 1050.1 && salBruto <= 1400.77)
                {
                    mTxtAliINSS.Text = "9,00%";
                    descontoINSS = 0.09 * salBruto;
                    salLiquido = salBruto - descontoINSS;
                    if (salBruto >= 1257.13)
                    {
                        mTxtAliquotaIRPF.Text = "15,00%";
                        aliquotaIRPF = salBruto * 0.15;
                        salLiquido -= aliquotaIRPF;
                    }
                    else
                        mTxtAliquotaIRPF.Text = "0";

                }
                else if (salBruto >= 1400.78 && salBruto <= 2801.56)
                {
                    mTxtAliINSS.Text = "11,00%";
                    descontoINSS = 0.11 * salBruto;
                    salLiquido = salBruto - descontoINSS;
                    if (salBruto <= 2512.08)
                    {
                        mTxtAliquotaIRPF.Text = "15,00%";
                        aliquotaIRPF = salBruto * 0.15;
                        salLiquido -= aliquotaIRPF;
                    }
                    else
                    {
                        mTxtAliquotaIRPF.Text = "27,50%";
                        aliquotaIRPF = salBruto * 0.275;
                        salLiquido -= aliquotaIRPF;
                    }
                }
                else if (salBruto >= 1400.78 && salBruto <= 2801.56)
                {
                    mTxtAliINSS.Text = "11,00%";
                    descontoINSS = 0.11 * salBruto;
                    salLiquido = salBruto - descontoINSS;
                    if (salBruto <= 2512.08)
                    {
                        mTxtAliquotaIRPF.Text = "15,00%";
                        aliquotaIRPF = salBruto * 0.15;
                        salLiquido -= aliquotaIRPF;
                    }
                    else
                    {
                        mTxtAliquotaIRPF.Text = "27,50%";
                        aliquotaIRPF = salBruto * 0.275;
                        salLiquido -= aliquotaIRPF;
                    }
                }
                else
                {
                    mTxtAliINSS.Text = "308.17";
                    mTxtSalarioFamilia.Text = "0";
                    mTxtAliquotaIRPF.Text = "27,50%";
                    descontoINSS = 308.17;
                    salLiquido = salBruto - descontoINSS;
                    aliquotaIRPF = salBruto * 0.275;
                    salLiquido -= aliquotaIRPF;
                }
            }
            mTxtSalarioLiquido.Text = Convert.ToString(salLiquido);
            mTxtDescontoINSS.Text = Convert.ToString(descontoINSS);
            mTxtDescontoIRPF.Text = Convert.ToString(aliquotaIRPF);
            string estadoCivil = "";
            string nome = Convert.ToString(txtNome.Text);
            string filhos = Convert.ToString(mTxtNumeroFilhos.Text);
            if (ckbxCasado.Checked)
                estadoCivil = "casado(a)";
            else
                estadoCivil = "solteiro(a)";
            lblDados.Text = "Os descontos do salario do(a) Sr(a)" + nome + "\n que é "
                + estadoCivil + "\n e que tem " + filhos + "filho(s) são: ";
        }
    }
}
