﻿namespace Ex2.Aula5
{
    partial class frmSalario
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSal = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnM = new System.Windows.Forms.RadioButton();
            this.rbtnF = new System.Windows.Forms.RadioButton();
            this.btnVerificaDesconto = new System.Windows.Forms.Button();
            this.lblAINSS = new System.Windows.Forms.Label();
            this.lblAIRPF = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.lblDINSS = new System.Windows.Forms.Label();
            this.lblDIRPF = new System.Windows.Forms.Label();
            this.lblDados = new System.Windows.Forms.Label();
            this.mTxtSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.mTxtNumeroFilhos = new System.Windows.Forms.MaskedTextBox();
            this.mTxtAliquotaIRPF = new System.Windows.Forms.MaskedTextBox();
            this.mTxtAliINSS = new System.Windows.Forms.MaskedTextBox();
            this.mTxtSalarioLiquido = new System.Windows.Forms.MaskedTextBox();
            this.mTxtSalarioFamilia = new System.Windows.Forms.MaskedTextBox();
            this.mTxtDescontoIRPF = new System.Windows.Forms.MaskedTextBox();
            this.mTxtDescontoINSS = new System.Windows.Forms.MaskedTextBox();
            this.gbxSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(29, 22);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(90, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome funcionario";
            // 
            // lblSal
            // 
            this.lblSal.AutoSize = true;
            this.lblSal.Location = new System.Drawing.Point(29, 54);
            this.lblSal.Name = "lblSal";
            this.lblSal.Size = new System.Drawing.Size(66, 13);
            this.lblSal.TabIndex = 1;
            this.lblSal.Text = "Salario bruto";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Location = new System.Drawing.Point(29, 92);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(86, 13);
            this.lblFilhos.TabIndex = 2;
            this.lblFilhos.Text = "Numero de filhos";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(126, 22);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 3;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Location = new System.Drawing.Point(298, 125);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(74, 17);
            this.ckbxCasado.TabIndex = 6;
            this.ckbxCasado.Text = "Casado(a)";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            // 
            // gbxSexo
            // 
            this.gbxSexo.Controls.Add(this.rbtnM);
            this.gbxSexo.Controls.Add(this.rbtnF);
            this.gbxSexo.Location = new System.Drawing.Point(270, 21);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Size = new System.Drawing.Size(134, 98);
            this.gbxSexo.TabIndex = 8;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // rbtnM
            // 
            this.rbtnM.AutoSize = true;
            this.rbtnM.Location = new System.Drawing.Point(28, 52);
            this.rbtnM.Name = "rbtnM";
            this.rbtnM.Size = new System.Drawing.Size(34, 17);
            this.rbtnM.TabIndex = 1;
            this.rbtnM.TabStop = true;
            this.rbtnM.Text = "M";
            this.rbtnM.UseVisualStyleBackColor = true;
            // 
            // rbtnF
            // 
            this.rbtnF.AutoSize = true;
            this.rbtnF.Location = new System.Drawing.Point(28, 30);
            this.rbtnF.Name = "rbtnF";
            this.rbtnF.Size = new System.Drawing.Size(31, 17);
            this.rbtnF.TabIndex = 0;
            this.rbtnF.TabStop = true;
            this.rbtnF.Text = "F";
            this.rbtnF.UseVisualStyleBackColor = true;
            // 
            // btnVerificaDesconto
            // 
            this.btnVerificaDesconto.Location = new System.Drawing.Point(89, 151);
            this.btnVerificaDesconto.Name = "btnVerificaDesconto";
            this.btnVerificaDesconto.Size = new System.Drawing.Size(137, 23);
            this.btnVerificaDesconto.TabIndex = 9;
            this.btnVerificaDesconto.Text = "Verificar desconto";
            this.btnVerificaDesconto.UseVisualStyleBackColor = true;
            this.btnVerificaDesconto.Click += new System.EventHandler(this.btnVerificaDesconto_Click);
            // 
            // lblAINSS
            // 
            this.lblAINSS.AutoSize = true;
            this.lblAINSS.Location = new System.Drawing.Point(23, 265);
            this.lblAINSS.Name = "lblAINSS";
            this.lblAINSS.Size = new System.Drawing.Size(73, 13);
            this.lblAINSS.TabIndex = 11;
            this.lblAINSS.Text = "Aliquota INSS";
            // 
            // lblAIRPF
            // 
            this.lblAIRPF.AutoSize = true;
            this.lblAIRPF.Location = new System.Drawing.Point(23, 297);
            this.lblAIRPF.Name = "lblAIRPF";
            this.lblAIRPF.Size = new System.Drawing.Size(72, 13);
            this.lblAIRPF.TabIndex = 12;
            this.lblAIRPF.Text = "Aliquota IRPF";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(23, 331);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(76, 13);
            this.lblSalFamilia.TabIndex = 13;
            this.lblSalFamilia.Text = "Salário Família";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Location = new System.Drawing.Point(23, 363);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(78, 13);
            this.lblSalLiquido.TabIndex = 14;
            this.lblSalLiquido.Text = "Salário Líquido";
            // 
            // lblDINSS
            // 
            this.lblDINSS.AutoSize = true;
            this.lblDINSS.Location = new System.Drawing.Point(248, 269);
            this.lblDINSS.Name = "lblDINSS";
            this.lblDINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDINSS.TabIndex = 19;
            this.lblDINSS.Text = "Desconto INSS";
            // 
            // lblDIRPF
            // 
            this.lblDIRPF.AutoSize = true;
            this.lblDIRPF.Location = new System.Drawing.Point(248, 301);
            this.lblDIRPF.Name = "lblDIRPF";
            this.lblDIRPF.Size = new System.Drawing.Size(80, 13);
            this.lblDIRPF.TabIndex = 20;
            this.lblDIRPF.Text = "Desconto IRPF";
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Location = new System.Drawing.Point(23, 207);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(48, 13);
            this.lblDados.TabIndex = 23;
            this.lblDados.Text = "lblDados";
            // 
            // mTxtSalarioBruto
            // 
            this.mTxtSalarioBruto.Location = new System.Drawing.Point(126, 54);
            this.mTxtSalarioBruto.Mask = "00000.00";
            this.mTxtSalarioBruto.Name = "mTxtSalarioBruto";
            this.mTxtSalarioBruto.Size = new System.Drawing.Size(100, 20);
            this.mTxtSalarioBruto.TabIndex = 24;
            // 
            // mTxtNumeroFilhos
            // 
            this.mTxtNumeroFilhos.Location = new System.Drawing.Point(126, 89);
            this.mTxtNumeroFilhos.Mask = "00";
            this.mTxtNumeroFilhos.Name = "mTxtNumeroFilhos";
            this.mTxtNumeroFilhos.Size = new System.Drawing.Size(100, 20);
            this.mTxtNumeroFilhos.TabIndex = 25;
            // 
            // mTxtAliquotaIRPF
            // 
            this.mTxtAliquotaIRPF.Enabled = false;
            this.mTxtAliquotaIRPF.Location = new System.Drawing.Point(126, 293);
            this.mTxtAliquotaIRPF.Name = "mTxtAliquotaIRPF";
            this.mTxtAliquotaIRPF.Size = new System.Drawing.Size(100, 20);
            this.mTxtAliquotaIRPF.TabIndex = 27;
            // 
            // mTxtAliINSS
            // 
            this.mTxtAliINSS.Enabled = false;
            this.mTxtAliINSS.Location = new System.Drawing.Point(126, 262);
            this.mTxtAliINSS.Name = "mTxtAliINSS";
            this.mTxtAliINSS.Size = new System.Drawing.Size(100, 20);
            this.mTxtAliINSS.TabIndex = 26;
            // 
            // mTxtSalarioLiquido
            // 
            this.mTxtSalarioLiquido.Enabled = false;
            this.mTxtSalarioLiquido.Location = new System.Drawing.Point(126, 363);
            this.mTxtSalarioLiquido.Name = "mTxtSalarioLiquido";
            this.mTxtSalarioLiquido.Size = new System.Drawing.Size(100, 20);
            this.mTxtSalarioLiquido.TabIndex = 29;
            // 
            // mTxtSalarioFamilia
            // 
            this.mTxtSalarioFamilia.Enabled = false;
            this.mTxtSalarioFamilia.Location = new System.Drawing.Point(126, 328);
            this.mTxtSalarioFamilia.Name = "mTxtSalarioFamilia";
            this.mTxtSalarioFamilia.Size = new System.Drawing.Size(100, 20);
            this.mTxtSalarioFamilia.TabIndex = 28;
            // 
            // mTxtDescontoIRPF
            // 
            this.mTxtDescontoIRPF.Enabled = false;
            this.mTxtDescontoIRPF.Location = new System.Drawing.Point(345, 301);
            this.mTxtDescontoIRPF.Name = "mTxtDescontoIRPF";
            this.mTxtDescontoIRPF.Size = new System.Drawing.Size(100, 20);
            this.mTxtDescontoIRPF.TabIndex = 31;
            // 
            // mTxtDescontoINSS
            // 
            this.mTxtDescontoINSS.Enabled = false;
            this.mTxtDescontoINSS.Location = new System.Drawing.Point(345, 266);
            this.mTxtDescontoINSS.Name = "mTxtDescontoINSS";
            this.mTxtDescontoINSS.Size = new System.Drawing.Size(100, 20);
            this.mTxtDescontoINSS.TabIndex = 30;
            // 
            // frmSalario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(468, 399);
            this.Controls.Add(this.mTxtDescontoIRPF);
            this.Controls.Add(this.mTxtDescontoINSS);
            this.Controls.Add(this.mTxtSalarioLiquido);
            this.Controls.Add(this.mTxtSalarioFamilia);
            this.Controls.Add(this.mTxtAliquotaIRPF);
            this.Controls.Add(this.mTxtAliINSS);
            this.Controls.Add(this.mTxtNumeroFilhos);
            this.Controls.Add(this.mTxtSalarioBruto);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.lblDIRPF);
            this.Controls.Add(this.lblDINSS);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblAIRPF);
            this.Controls.Add(this.lblAINSS);
            this.Controls.Add(this.btnVerificaDesconto);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.ckbxCasado);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSal);
            this.Controls.Add(this.lblNome);
            this.Name = "frmSalario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cálculo de Salário";
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSal;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.CheckBox ckbxCasado;
        private System.Windows.Forms.GroupBox gbxSexo;
        private System.Windows.Forms.RadioButton rbtnM;
        private System.Windows.Forms.RadioButton rbtnF;
        private System.Windows.Forms.Button btnVerificaDesconto;
        private System.Windows.Forms.Label lblAINSS;
        private System.Windows.Forms.Label lblAIRPF;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.Label lblDINSS;
        private System.Windows.Forms.Label lblDIRPF;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.MaskedTextBox mTxtSalarioBruto;
        private System.Windows.Forms.MaskedTextBox mTxtNumeroFilhos;
        private System.Windows.Forms.MaskedTextBox mTxtAliquotaIRPF;
        private System.Windows.Forms.MaskedTextBox mTxtAliINSS;
        private System.Windows.Forms.MaskedTextBox mTxtSalarioLiquido;
        private System.Windows.Forms.MaskedTextBox mTxtSalarioFamilia;
        private System.Windows.Forms.MaskedTextBox mTxtDescontoIRPF;
        private System.Windows.Forms.MaskedTextBox mTxtDescontoINSS;
    }
}

