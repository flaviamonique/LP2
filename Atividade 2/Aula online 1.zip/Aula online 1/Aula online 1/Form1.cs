﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula_online_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double altura, pesoAtual, PesoIdeal;
            
            if (double.TryParse(txtPesoAtual.Text, out pesoAtual) && double.TryParse(txtAltura.Text, out altura))
            {
                pesoAtual = Convert.ToDouble(txtPesoAtual.Text);
                pesoAtual = Math.Round(pesoAtual, 2);
                altura = Convert.ToDouble(txtAltura.Text);

                if (rbtnMulher.Checked)
                {
                    PesoIdeal = (62.1 * altura) - 44.7;
                }
                else
                {
                    PesoIdeal = (72.7 * altura) - 58;
                }
                PesoIdeal = Math.Round(PesoIdeal, 2);

                if (pesoAtual < PesoIdeal)
                {
                    MessageBox.Show("Esta abaixo do peso ideal");
                }
                else if (PesoIdeal == pesoAtual)
                {
                    MessageBox.Show("Esta no peso ideal");
                }
                else
                {
                    MessageBox.Show("Esta acima do peso ideal");
                }
            }
            else
            {
                MessageBox.Show("Dados da altura ou peso invalidos");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtPesoAtual_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
